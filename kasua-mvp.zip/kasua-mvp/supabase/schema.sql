-- KASUA MVP — Supabase/PostgreSQL schema
-- Run this in Supabase SQL Editor on a fresh project.
create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  category text not null default 'Other',
  description text,
  location text,
  phone text,
  logo_url text,
  opening_hours jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  location text,
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  name text not null,
  description text,
  category text not null default 'Other',
  price numeric(14,2) not null check (price >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  image_url text,
  sku text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- Enforce that a product's selected branch belongs to the same business.
create or replace function public.validate_product_branch()
returns trigger language plpgsql set search_path = public
as $$
begin
  if new.branch_id is not null and not exists (
    select 1 from public.branches b where b.id = new.branch_id and b.business_id = new.business_id
  ) then
    raise exception 'Branch does not belong to this business';
  end if;
  return new;
end;
$$;
drop trigger if exists products_branch_guard on public.products;
create trigger products_branch_guard before insert or update of branch_id, business_id on public.products
for each row execute function public.validate_product_branch();

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  product_id uuid references public.products(id) on delete set null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  total numeric(14,2) not null check (total >= 0),
  channel text not null default 'in_store',
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  title text not null,
  category text not null default 'Other',
  amount numeric(14,2) not null check (amount > 0),
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists businesses_owner_idx on public.businesses(owner_id);
create index if not exists products_market_idx on public.products(is_active, category, created_at desc);
create index if not exists products_business_idx on public.products(business_id, branch_id);
create index if not exists sales_business_date_idx on public.sales(business_id, created_at desc);
create index if not exists expenses_business_date_idx on public.expenses(business_id, created_at desc);

create or replace function public.owns_business(target_business uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.businesses b where b.id = target_business and b.owner_id = auth.uid()); $$;

alter table public.businesses enable row level security;
alter table public.branches enable row level security;
alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;

-- Public read access is limited to active business identities and active products.
create policy "Public can view active businesses" on public.businesses for select using (is_active = true or owner_id = auth.uid());
create policy "Owners manage their businesses" on public.businesses for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "Public can view active branches" on public.branches for select using (is_active = true or public.owns_business(business_id));
create policy "Owners manage branches" on public.branches for all using (public.owns_business(business_id)) with check (public.owns_business(business_id));
create policy "Public can view active products" on public.products for select using (is_active = true or public.owns_business(business_id));
create policy "Owners manage products" on public.products for all using (public.owns_business(business_id)) with check (public.owns_business(business_id));
create policy "Owners view sales" on public.sales for select using (public.owns_business(business_id));
create policy "Owners manage sales" on public.sales for insert with check (public.owns_business(business_id));
create policy "Owners view expenses" on public.expenses for select using (public.owns_business(business_id));
create policy "Owners manage expenses" on public.expenses for all using (public.owns_business(business_id)) with check (public.owns_business(business_id));

-- Atomic sale recording: validates ownership and stock, records sale and decrements stock together.
create or replace function public.record_sale(
  p_business_id uuid,
  p_branch_id uuid,
  p_product_id uuid,
  p_quantity integer,
  p_unit_price numeric
) returns public.sales
language plpgsql security definer set search_path = public
as $$
declare
  v_product public.products;
  v_sale public.sales;
begin
  if not public.owns_business(p_business_id) then
    raise exception 'You do not have permission to record sales for this business';
  end if;
  if p_quantity is null or p_quantity <= 0 then raise exception 'Quantity must be greater than zero'; end if;
  select * into v_product from public.products
    where id = p_product_id and business_id = p_business_id for update;
  if not found then raise exception 'Product not found'; end if;
  if v_product.stock_quantity < p_quantity then raise exception 'Insufficient stock'; end if;
  if p_branch_id is not null and not exists(select 1 from public.branches where id=p_branch_id and business_id=p_business_id) then
    raise exception 'Branch does not belong to this business';
  end if;
  update public.products set stock_quantity = stock_quantity - p_quantity, updated_at = now() where id = p_product_id;
  insert into public.sales(business_id,branch_id,product_id,quantity,unit_price,total)
  values(p_business_id,p_branch_id,p_product_id,p_quantity,p_unit_price,p_quantity*p_unit_price)
  returning * into v_sale;
  return v_sale;
end;
$$;
revoke all on function public.record_sale(uuid,uuid,uuid,integer,numeric) from public;
grant execute on function public.record_sale(uuid,uuid,uuid,integer,numeric) to authenticated;

-- Keep public storefront queries efficient.
grant select on public.businesses, public.branches, public.products to anon, authenticated;
grant insert, update, delete on public.businesses, public.branches, public.products, public.expenses to authenticated;
grant select, insert on public.sales to authenticated;
